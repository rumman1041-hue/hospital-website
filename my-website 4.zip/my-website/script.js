// Appointment form submit
function submitAppointment() {
    const name = document.getElementById("name").value.trim();
    const number = document.getElementById("number").value.trim();
    const date = document.getElementById("date").value;
    const time = document.getElementById("time").value;

    // Validation
    if (name === "" || number === "" || date === "" || time === "") {
        alert("Please fill all appointment details.");
        return false;
    }

    
const phonePattern = /^03\d{9}$/;

if (!phonePattern.test(number)) {
    alert("Phone number must start with 03 and be exactly 11 digits.");
    return false;
}


    // Success message
    alert(
        "Appointment Booked Successfully!\n\n" +
        "Name: " + name + "\n" +
        "Number: " + number + "\n" +
        "Date: " + date + "\n" +
        "Time: " + time
    );

    // Reset form
    document.getElementById("appointmentForm").reset();

    return false;
}

// Disable past dates
window.onload = function () {
    const today = new Date().toISOString().split("T")[0];
    document.getElementById("date").setAttribute("min", today);
};

