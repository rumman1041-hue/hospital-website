document.addEventListener('DOMContentLoaded', () => {

    
z
    const nav = document.querySelector('nav');
    if (nav) {
        window.addEventListener('scroll', () => {
            nav.classList.toggle('sticky', window.scrollY > 50);
        });
    }

    const mainTxt = document.querySelector('.mainTxt');
    if (mainTxt) {
        let index = 0;
        const texts = ["Welcome to Central Care", "Smart. Secure. Reliable.", "Your Health is Our Priority"];
        function changeText() {
            mainTxt.textContent = texts[index];
            index = (index + 1) % texts.length;
        }
        changeText();
        setInterval(changeText, 3000);
    }

    const cards = document.querySelectorAll('.card, .service-card, .doctor-card, .blog-card');
    if (cards.length) {
        cards.forEach(card => {
            card.addEventListener('mouseenter', () => card.classList.add('hover'));
            card.addEventListener('mouseleave', () => card.classList.remove('hover'));
        });
    }

    
    const backBtn = document.createElement('button');
    backBtn.className = 'back-to-top';
    backBtn.textContent = '↑ Top';
    document.body.appendChild(backBtn);

    backBtn.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    window.addEventListener('scroll', () => {
        backBtn.style.display = window.scrollY > 300 ? 'block' : 'none';
    });


    const appointmentForm = document.querySelector('#Appointment .form');
    if (appointmentForm) {
        const submitBtn = appointmentForm.querySelector('button');
        submitBtn.addEventListener('click', (e) => {
            e.preventDefault();
            const inputs = appointmentForm.querySelectorAll('input');
            let valid = true;
            inputs.forEach(input => {
                if (!input.value.trim()) valid = false;
            });
            if (!valid) {
                alert("Please fill all the fields!");
                return;
            }
            alert("Appointment submitted successfully!");
            inputs.forEach(input => input.value = "");
        });
    }


    const doctorFilter = document.querySelector('#doctor-filter'); 
    if (doctorFilter) {
        doctorFilter.addEventListener('change', () => {
            const specialization = doctorFilter.value.toLowerCase();
            const doctors = document.querySelectorAll('.doctor-card');
            doctors.forEach(doc => {
                const spec = doc.querySelector('p').textContent.toLowerCase();
                if (specialization === 'all' || spec === specialization) {
                    doc.style.display = 'block';
                } else {
                    doc.style.display = 'none';
                }
            });
        });
    }

    const blogFilter = document.querySelector('#blog-filter'); 
    if (blogFilter) {
        blogFilter.addEventListener('change', () => {
            const category = blogFilter.value.toLowerCase();
            const blogs = document.querySelectorAll('.blog-card');
            blogs.forEach(blog => {
                const cat = blog.dataset.category.toLowerCase();
                if (category === 'all' || cat === category) {
                    blog.style.display = 'block';
                } else {
                    blog.style.display = 'none';
                }
            });
        });
    }

    
    const readMoreBtns = document.querySelectorAll('.read-more');
    if (readMoreBtns.length) {
        readMoreBtns.forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                const para = btn.previousElementSibling;
                if (para.style.maxHeight) {
                    para.style.maxHeight = null;
                    btn.textContent = "Read More";
                } else {
                    para.style.maxHeight = para.scrollHeight + "px";
                    btn.textContent = "Read Less";
                }
            });
        });
    }

});