name={
    "ali":["math","physics"],
    "Sara":["math","physics"]
}
new_dic={}
for name,subjects in data.items():
    new_dic[name]=tuple(subjects)
print(new_dic)